%TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*%
%TF.CreationDate,2026-01-05T21:01:46+01:00*%
%TF.ProjectId,NURD-template,4e555244-2d74-4656-9d70-6c6174652e6b,rev?*%
%TF.SameCoordinates,PX5f5e100PY5f5e100*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-01-05 21:01:46*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.000000*%
G04 APERTURE END LIST*
D10*
%TO.C,FID103*%
X103400000Y-77650000D03*
%TD*%
%TO.C,FID104*%
X103400000Y-80200000D03*
%TD*%
%TO.C,FID101*%
X103400000Y-72550000D03*
%TD*%
%TO.C,FID102*%
X103400000Y-75100000D03*
%TD*%
M02*
